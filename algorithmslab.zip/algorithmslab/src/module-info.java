module algorithmslab {
}